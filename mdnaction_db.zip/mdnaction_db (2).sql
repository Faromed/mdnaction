-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 24 avr. 2025 à 13:44
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mdnaction_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$HtvXnYE3xV26cSquADjxoOVzYrkCKVNG4V56aP0lRqz00HUaLDz2y');

-- --------------------------------------------------------

--
-- Structure de la table `blog`
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `contenu` text,
  `auteur` varchar(100) DEFAULT NULL,
  `date_publication` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) DEFAULT NULL,
  `date_modification` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `blog`
--

INSERT INTO `blog` (`id`, `titre`, `contenu`, `auteur`, `date_publication`, `image`, `date_modification`) VALUES
(8, 'Optimisation SEO en 2025', '<p>Les stratégies SEO évoluent constamment. Voici les techniques les plus efficaces pour améliorer le référencement de votre site en 2025.</p>', 'Paterne Zola', '2025-01-25 15:45:00', 'seo.jpg', '2025-01-25 15:45:00'),
(7, 'L\'avenir de l\'IA dans le développement web', '<p>L\'intelligence artificielle révolutionne la façon dont nous créons et gérons les sites web.</p><p>Découvrez comment intégrer l\'IA dans vos projets web.</p>', 'Déo Gracia', '2025-01-20 08:15:00', 'ia-developpeurs.jpg', '2025-04-18 08:31:58'),
(6, 'Introduction à PHP 8.3', '<p>PHP 8.3 apporte de nombreuses améliorations et fonctionnalités qui facilitent le développement d\'applications web.</p><p>Découvrez les nouveautés dans cet article complet.</p>', 'Expédit LACHILO', '2025-01-15 13:30:00', 'img8.jpg', '2025-04-17 15:17:20'),
(5, 'Les meilleures pratiques en développement web', '<p>Dans cet article, nous explorerons les meilleures pratiques actuelles en développement web pour 2025.</p><p>La performance et l\'accessibilité sont devenues essentielles pour tout site web moderne.</p>', 'Farel Medenou', '2025-01-10 09:00:00', 'web.jpg', '2025-04-17 15:17:02'),
(9, 'Sécuriser vos applications web', '<p>La sécurité web est primordiale. Découvrez les meilleures pratiques pour protéger vos applications contre les attaques courantes.</p>', 'Marcel Ayedoun', '2025-02-01 10:20:00', 'maint.jpg', '2025-04-18 09:06:10'),
(10, 'React vs Vue en 2025', '<p>Comparaison détaillée des frameworks React et Vue.js. Lequel choisir pour vos projets en 2025?</p>', 'Nadine Dossou', '2025-02-05 12:30:00', 'javascript-propre.jpg', '2025-04-18 09:04:28'),
(11, 'Les outils indispensables pour tout développeur web', '<p>Découvrez la liste des outils et extensions qui amélioreront significativement votre productivité en tant que développeur web.</p>', 'François Amoussou', '2025-02-10 09:10:00', '68021726d5041.jpg', '2025-04-18 09:13:03'),
(12, 'Comment créer une API RESTful avec Laravel', '<p>Guide pas à pas pour développer une API RESTful robuste et sécurisée avec le framework Laravel.</p>', 'Sophie Koudjo', '2025-02-15 14:25:00', 'img5.jpg', '2025-04-18 09:06:29'),
(13, 'Les tendances du design web en 2025', '<p>Explorez les dernières tendances en matière de design web qui captiveront vos visiteurs et amélioreront l\'expérience utilisateur.</p>', 'Bruno Mensah', '2025-02-20 08:45:00', 'web.jpg', '2025-04-18 09:07:48'),
(14, 'Optimiser les performances de votre site WordPress', '<p>Techniques avancées pour accélérer votre site WordPress et améliorer son temps de chargement.</p>', 'Claire Agossa', '2025-02-25 13:15:00', 'optimisation-wordpress.jpg', '2025-02-25 13:15:00'),
(15, 'Introduction à Docker pour les développeurs web', '<p>Apprenez à utiliser Docker pour simplifier et standardiser votre environnement de développement web.</p>', 'Vincent Lokossa', '2025-03-01 10:30:00', 'img8.jpg', '2025-04-18 09:08:08'),
(16, 'Les bases de TypeScript pour les développeurs JavaScript', '<p>Découvrez comment TypeScript peut améliorer la qualité et la maintenabilité de votre code JavaScript.</p>', 'Marie Dansou', '2025-03-05 15:50:00', 'img9.jpg', '2025-04-18 09:08:00'),
(17, 'Comment implémenter l\'authentification OAuth2', '<p>Guide complet pour mettre en place l\'authentification OAuth2 dans vos applications web.</p>', 'David Akplogan', '2025-03-10 09:40:00', 'optimisation-wordpress.jpg', '2025-04-18 09:08:19'),
(18, 'Les erreurs courantes en CSS et comment les éviter', '<p>Identifiez et corrigez les erreurs CSS les plus fréquentes qui peuvent affecter la mise en page de votre site.</p>', 'Nadège Houessou', '2025-03-15 12:20:00', 'img4.jpg', '2025-04-18 09:06:42'),
(19, 'Développement mobile avec React Native', '<p>Créez des applications mobiles performantes pour iOS et Android avec React Native.</p>', 'Paul Adekambi', '2025-03-20 14:10:00', 'javascript-propre.jpg', '2025-04-18 09:08:47'),
(20, 'Comment améliorer l\'accessibilité de votre site web', '<p>Conseils pratiques pour rendre votre site accessible à tous les utilisateurs, y compris ceux ayant des handicaps.</p>', 'Estelle Gankpa', '2025-03-25 08:30:00', 'img1.webp', '2025-04-18 09:13:30'),
(21, 'Les bases de données NoSQL vs SQL', '<p>Comparaison détaillée entre les bases de données relationnelles et non relationnelles. Quand utiliser chacune? Ces requêtes SQL vous permettront d\'insérer 20 enregistrements dans chacune des tables spécifiées (compétences, formations, projets, services et témoignages), en utilisant les noms d\'images que vous avez fournis. Chaque ensemble de données est varié et cohérent avec la structure de votre base de données. Vous pouvez exécuter ces requêtes dans phpMyAdmin ou tout autre outil de gestion de base de données MySQL.RéessayerClaude n\'a pas encore la capacité d\'exécuter le code qu\'il génère.Claude peut faire des erreurs. Assurez-vous de vérifier ses réponses. Ces requêtes SQL vous permettront d\'insérer 20 enregistrements dans chacune des tables spécifiées (compétences, formations, projets, services et témoignages), en utilisant les noms d\'images que vous avez fournis. Chaque ensemble de données est varié et cohérent avec la structure de votre base de données. Vous pouvez exécuter ces requêtes dans phpMyAdmin ou tout autre outil de gestion de base de données MySQL.RéessayerClaude n\'a pas encore la capacité d\'exécuter le code qu\'il génère.Claude peut faire des erreurs. Assurez-vous de vérifier ses réponses. Ces requêtes SQL vous permettront d\'insérer 20 enregistrements dans chacune des tables spécifiées (compétences, formations, projets, services et témoignages), en utilisant les noms d\'images que vous avez fournis. Chaque ensemble de données est varié et cohérent avec la structure de votre base de données. Vous pouvez exécuter ces requêtes dans phpMyAdmin ou tout autre outil de gestion de base de données MySQL.RéessayerClaude n\'a pas encore la capacité d\'exécuter le code qu\'il génère.Claude peut faire des erreurs. Assurez-vous de vérifier ses réponses.</p>', 'Robert Ahouandjinou', '2025-03-30 13:45:00', 'img2.jpg', '2025-04-18 08:33:21'),
(22, 'Guide complet sur Git pour les débutants', '<p>Apprenez les bases de Git et du versioning de code pour collaborer efficacement sur des projets de développement.</p>', 'Sylvie Agbo', '2025-04-01 09:25:00', 'img3.jpg', '2025-04-18 09:09:32'),
(23, 'Les frameworks CSS en 2025', '<p>Découvrez les frameworks CSS les plus populaires et comment choisir celui qui convient le mieux à vos projets.</p>', 'Thomas Quenum', '2025-04-05 15:15:00', '6800db6ed97a6.jpg', '2025-04-17 15:16:55'),
(24, 'Techniques de débogage avancées pour JavaScript', '<p>Maîtrisez les outils et techniques de débogage pour résoudre efficacement les problèmes dans votre code JavaScript.</p>', 'Aimée Gbaguidi', '2025-04-10 10:50:00', 'maint.jpg', '2025-04-17 15:07:36'),
(25, 'Comment implémenter une PWA', '<p>Guide étape par étape pour transformer votre site web en Progressive Web App (PWA).</p>', 'Michel Adjovi', '2025-04-15 12:40:00', 'img3.jpg', '2025-04-18 14:46:09'),
(26, 'Les tests automatisés en développement web', '<p>L\'importance des tests unitaires, d\'intégration et end-to-end pour garantir la qualité de votre code.</p>', 'Carine Assogba', '2025-04-16 14:30:00', 'ecom.png', '2025-04-17 15:05:39'),
(27, 'Développement web éthique et responsable', '<p>Comment créer des sites web qui respectent les principes éthiques et environnementaux.</p>', 'Luc Dossou', '2025-03-22 08:20:00', 'img5.webp', '2025-04-18 09:07:32'),
(28, 'Les microservices en architecture web', '<p>Introduction à l\'architecture microservices et ses avantages pour le développement d\'applications web scalables.</p>', 'Jeanne Adohinzin', '2025-03-27 13:05:00', 'banniere.png', '2025-04-18 09:10:07'),
(29, 'Sécuriser vos API avec JWT', '<p>Utilisez les JSON Web Tokens pour sécuriser l\'accès à vos API de manière efficace.</p>', 'Georges Tonato', '2025-04-02 09:55:00', '68010270e32f6.jpg', '2025-04-18 09:06:56'),
(30, 'Comment créer un thème WordPress personnalisé', '<p>Guide complet pour développer un thème WordPress sur mesure pour vos clients.</p>', 'Patricia Avognon', '2025-04-07 15:35:00', 'img4.jpg', '2025-04-17 15:08:08'),
(31, 'Les outils d\'analyse web indispensables', '<p>Découvrez les meilleurs outils pour analyser les performances et le comportement des utilisateurs sur votre site web.</p>', 'Antoine Zinsou', '2025-04-12 10:25:00', 'img5.jpg', '2025-04-17 15:07:03'),
(32, 'Introduction au WebAssembly', '<p>Comment WebAssembly transforme le développement web en permettant d\'exécuter du code à vitesse native dans le navigateur.</p>', 'Nicole Akakpo', '2025-02-18 12:15:00', 'img1.webp', '2025-04-18 09:07:10'),
(33, 'Le rôle de la blockchain dans le développement web', '<p>Découvrez comment intégrer la technologie blockchain dans vos applications web pour plus de sécurité et de transparence.</p>', 'Bernard Sokpin', '2025-02-22 14:50:00', '67fe09a8b22ff.jpg', '2025-04-18 09:07:20'),
(34, 'L\'importance du référencement local', '<p>Stratégies pour améliorer la visibilité de votre entreprise dans les recherches locales grâce à un bon référencement.</p>', 'Charlotte Houngbo', '2025-02-28 08:40:00', '6802176bb48a5.jpg', '2025-04-18 09:12:35');

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

DROP TABLE IF EXISTS `commentaires`;
CREATE TABLE IF NOT EXISTS `commentaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contenu` text NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `est_approuve` tinyint(1) DEFAULT '0',
  `date_modification` timestamp NOT NULL,
  `reponse_admin` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaires`
--

INSERT INTO `commentaires` (`id`, `article_id`, `nom`, `email`, `contenu`, `date_creation`, `est_approuve`, `date_modification`, `reponse_admin`) VALUES
(1, 2, 'Farel Medenou', 'farelmedenou2018@gmail.com', 'J\'ai beaucoup aimé cette formation, c', '2025-04-10 16:00:34', 1, '0000-00-00 00:00:00', ''),
(2, 1, 'Expédit LACHILO', 'expeditlachilo796@gmail.com', 'J\'ai beaucoup aimé cette formation, c\'est vraiment 100% pratique.', '2025-04-11 08:31:50', 0, '0000-00-00 00:00:00', ''),
(3, 3, 'Déo Gracia ', 'devsigrhp@gmail.com', 'L\'intelligence artificielle est très intéressante à apprendre. Je vous conseil vivement de suivre cette formation ', '2025-04-11 08:33:54', 1, '0000-00-00 00:00:00', ''),
(4, 1, 'FAREL MEDENOU ', 'faromed@gmail.com', 'Je suis satisfaite', '2025-04-15 08:25:06', 1, '0000-00-00 00:00:00', ''),
(5, 3, 'Déo Gracia ', 'devsigrhp@gmail.com', 'je suis d\'accord que ça se passe comme ceci. Sinon d\'ici 10ans, le monde vas devenir autre chose grâce à l\'intelligence artificielle\r\n', '2025-04-15 15:18:08', 0, '0000-00-00 00:00:00', ''),
(6, 3, 'Paterne Zola', 'expeditlachilo796@gmail.com', 'Je ne sais pas quoi dire, mais je penses que c\'est une bonne initiative ', '2025-04-15 15:18:55', 0, '0000-00-00 00:00:00', ''),
(7, 3, 'Paterne Zola', 'expeditlachilo796@gmail.com', 'Je ne sais pas quoi dire, mais je penses que c\'est une bonne initiative ', '2025-04-17 07:48:44', 1, '2025-04-17 10:04:08', ''),
(8, 1, 'Jean Dupont', 'jean.dupont@gmail.com', 'Article très instructif, merci pour ces conseils pratiques !', '2025-01-11 13:20:00', 1, '2025-01-11 14:00:00', ''),
(9, 1, 'Jean Dupont', 'jean.dupont@gmail.com', 'Article très instructif, merci pour ces conseils pratiques !', '2025-01-11 13:20:00', 1, '2025-01-11 14:00:00', ''),
(10, 1, 'Marie Lefebvre', 'marie.lefebvre@yahoo.fr', 'J\'aurais aimé plus d\'exemples concrets, mais l\'article est bien écrit.', '2025-01-12 08:30:00', 1, '2025-01-12 09:15:00', 'Merci pour votre retour, nous allons enrichir l\'article avec plus d\'exemples.'),
(11, 1, 'Marie Lefebvre', 'marie.lefebvre@yahoo.fr', 'J\'aurais aimé plus d\'exemples concrets, mais l\'article est bien écrit.', '2025-01-12 08:30:00', 1, '2025-01-12 09:15:00', 'Merci pour votre retour, nous allons enrichir l\'article avec plus d\'exemples.'),
(12, 2, 'Pierre Martin', 'pierre.martin@hotmail.com', 'Les nouveautés de PHP 8.3 sont vraiment impressionnantes !', '2025-01-16 15:45:00', 1, '2025-01-16 16:20:00', ''),
(13, 2, 'Pierre Martin', 'pierre.martin@hotmail.com', 'Les nouveautés de PHP 8.3 sont vraiment impressionnantes !', '2025-01-16 15:45:00', 1, '2025-01-16 16:20:00', ''),
(14, 2, 'Sophie Moreau', 'sophie.moreau@gmail.com', 'Est-ce que vous pourriez faire un tutoriel sur les attributs de PHP 8.3 ?', '2025-01-17 09:05:00', 0, '2025-01-17 09:05:00', ''),
(15, 2, 'Sophie Moreau', 'sophie.moreau@gmail.com', 'Est-ce que vous pourriez faire un tutoriel sur les attributs de PHP 8.3 ?', '2025-01-17 09:05:00', 0, '2025-01-17 09:05:00', ''),
(16, 3, 'Lucas Bernard', 'lucas.bernard@gmail.com', 'L\'IA va révolutionner notre façon de travailler, c\'est certain !', '2025-01-21 12:30:00', 1, '2025-01-21 13:10:00', ''),
(17, 3, 'Lucas Bernard', 'lucas.bernard@gmail.com', 'L\'IA va révolutionner notre façon de travailler, c\'est certain !', '2025-01-21 12:30:00', 1, '2025-01-21 13:10:00', ''),
(18, 3, 'Emma Petit', 'emma.petit@yahoo.fr', 'Quels sont les meilleurs outils d\'IA pour les développeurs débutants ?', '2025-01-22 08:15:00', 1, '2025-01-22 09:00:00', 'Nous prévoyons un article sur ce sujet très prochainement !'),
(19, 3, 'Emma Petit', 'emma.petit@yahoo.fr', 'Quels sont les meilleurs outils d\'IA pour les développeurs débutants ?', '2025-01-22 08:15:00', 1, '2025-01-22 09:00:00', 'Nous prévoyons un article sur ce sujet très prochainement !'),
(20, 4, 'Thomas Durand', 'thomas.durand@gmail.com', 'Vos conseils SEO m\'ont déjà permis d\'améliorer le classement de mon site !', '2025-01-26 14:40:00', 1, '2025-01-26 15:20:00', ''),
(21, 4, 'Thomas Durand', 'thomas.durand@gmail.com', 'Vos conseils SEO m\'ont déjà permis d\'améliorer le classement de mon site !', '2025-01-26 14:40:00', 1, '2025-01-26 15:20:00', ''),
(22, 4, 'Julie Legrand', 'julie.legrand@hotmail.com', 'Les techniques mentionnées sont-elles applicables aux petits sites ?', '2025-01-27 10:25:00', 0, '2025-01-27 10:25:00', ''),
(23, 4, 'Julie Legrand', 'julie.legrand@hotmail.com', 'Les techniques mentionnées sont-elles applicables aux petits sites ?', '2025-01-27 10:25:00', 0, '2025-01-27 10:25:00', ''),
(24, 5, 'Nicolas Fournier', 'nicolas.fournier@gmail.com', 'La sécurité est souvent négligée, merci pour ce rappel important !', '2025-02-02 13:10:00', 1, '2025-02-02 14:00:00', ''),
(25, 5, 'Nicolas Fournier', 'nicolas.fournier@gmail.com', 'La sécurité est souvent négligée, merci pour ce rappel important !', '2025-02-02 13:10:00', 1, '2025-02-02 14:00:00', ''),
(26, 5, 'Sarah Dubois', 'sarah.dubois@yahoo.fr', 'Pourriez-vous faire un article sur les attaques CSRF spécifiquement ?', '2025-02-03 08:45:00', 1, '2025-02-03 09:30:00', 'Excellente suggestion, nous allons y travailler !'),
(27, 5, 'Sarah Dubois', 'sarah.dubois@yahoo.fr', 'Pourriez-vous faire un article sur les attaques CSRF spécifiquement ?', '2025-02-03 08:45:00', 1, '2025-02-03 09:30:00', 'Excellente suggestion, nous allons y travailler !'),
(28, 6, 'Antoine Girard', 'antoine.girard@gmail.com', 'Vue.js reste mon préféré pour sa simplicité !', '2025-02-06 15:20:00', 1, '2025-02-06 16:00:00', ''),
(29, 6, 'Antoine Girard', 'antoine.girard@gmail.com', 'Vue.js reste mon préféré pour sa simplicité !', '2025-02-06 15:20:00', 1, '2025-02-06 16:00:00', ''),
(30, 6, 'Laura Simon', 'laura.simon@hotmail.com', 'React a une communauté plus large, c\'est un avantage non négligeable.', '2025-02-07 09:35:00', 0, '2025-02-07 09:35:00', ''),
(31, 6, 'Laura Simon', 'laura.simon@hotmail.com', 'React a une communauté plus large, c\'est un avantage non négligeable.', '2025-02-07 09:35:00', 0, '2025-04-18 08:05:21', ''),
(32, 7, 'Rémi Leroy', 'remi.leroy@gmail.com', 'J\'utilise déjà plusieurs de ces outils, ils sont vraiment indispensables !', '2025-02-11 12:40:00', 1, '2025-02-11 13:15:00', ''),
(33, 7, 'Rémi Leroy', 'remi.leroy@gmail.com', 'J\'utilise déjà plusieurs de ces outils, ils sont vraiment indispensables !', '2025-02-11 12:40:00', 1, '2025-02-11 13:15:00', ''),
(34, 7, 'Claire Mercier', 'claire.mercier@yahoo.fr', 'Avez-vous des recommandations pour les outils de test de performance ?', '2025-02-12 08:25:00', 1, '2025-02-12 09:10:00', 'Nous recommandons Lighthouse et WebPageTest, nous ferons un article détaillé à ce sujet.'),
(35, 7, 'Claire Mercier', 'claire.mercier@yahoo.fr', 'Avez-vous des recommandations pour les outils de test de performance ?', '2025-02-12 08:25:00', 1, '2025-02-12 09:10:00', 'Nous recommandons Lighthouse et WebPageTest, nous ferons un article détaillé à ce sujet.'),
(37, 8, 'Hugo Blanc', 'hugo.blanc@gmail.com', 'Ce guide m\'a permis de créer ma première API avec Laravel, merci !', '2025-02-16 14:30:00', 1, '2025-04-18 08:02:51', 'ça fait plaisir'),
(38, 8, 'Jean Dupont', 'jean.dupont@gmail.com', 'Article très instructif, merci pour ces conseils pratiques !', '2025-01-11 13:20:00', 1, '2025-01-11 14:00:00', ''),
(39, 8, 'Jean Dupont', 'jean.dupont@gmail.com', 'Article très instructif, merci pour ces conseils pratiques !', '2025-01-11 13:20:00', 1, '2025-01-11 14:00:00', ''),
(40, 9, 'Marie Lefebvre', 'marie.lefebvre@yahoo.fr', 'J\'aurais aimé plus d\'exemples concrets, mais l\'article est bien écrit.', '2025-01-12 08:30:00', 1, '2025-01-12 09:15:00', 'Merci pour votre retour, nous allons enrichir l\'article avec plus d\'exemples.'),
(41, 9, 'Marie Lefebvre', 'marie.lefebvre@yahoo.fr', 'J\'aurais aimé plus d\'exemples concrets, mais l\'article est bien écrit.', '2025-01-12 08:30:00', 1, '2025-01-12 09:15:00', 'Merci pour votre retour, nous allons enrichir l\'article avec plus d\'exemples.'),
(42, 9, 'Pierre Martin', 'pierre.martin@hotmail.com', 'Les nouveautés de PHP 8.3 sont vraiment impressionnantes !', '2025-01-16 15:45:00', 1, '2025-01-16 16:20:00', ''),
(43, 9, 'Pierre Martin', 'pierre.martin@hotmail.com', 'Les nouveautés de PHP 8.3 sont vraiment impressionnantes !', '2025-01-16 15:45:00', 1, '2025-01-16 16:20:00', ''),
(44, 9, 'Sophie Moreau', 'sophie.moreau@gmail.com', 'Est-ce que vous pourriez faire un tutoriel sur les attributs de PHP 8.3 ?', '2025-01-17 09:05:00', 0, '2025-01-17 09:05:00', ''),
(45, 9, 'Sophie Moreau', 'sophie.moreau@gmail.com', 'Est-ce que vous pourriez faire un tutoriel sur les attributs de PHP 8.3 ?', '2025-01-17 09:05:00', 0, '2025-01-17 09:05:00', ''),
(46, 10, 'Lucas Bernard', 'lucas.bernard@gmail.com', 'L\'IA va révolutionner notre façon de travailler, c\'est certain !', '2025-01-21 12:30:00', 1, '2025-01-21 13:10:00', ''),
(47, 10, 'Lucas Bernard', 'lucas.bernard@gmail.com', 'L\'IA va révolutionner notre façon de travailler, c\'est certain !', '2025-01-21 12:30:00', 1, '2025-01-21 13:10:00', ''),
(48, 10, 'Emma Petit', 'emma.petit@yahoo.fr', 'Quels sont les meilleurs outils d\'IA pour les développeurs débutants ?', '2025-01-22 08:15:00', 1, '2025-01-22 09:00:00', 'Nous prévoyons un article sur ce sujet très prochainement !'),
(49, 10, 'Emma Petit', 'emma.petit@yahoo.fr', 'Quels sont les meilleurs outils d\'IA pour les développeurs débutants ?', '2025-01-22 08:15:00', 1, '2025-01-22 09:00:00', 'Nous prévoyons un article sur ce sujet très prochainement !'),
(50, 11, 'Thomas Durand', 'thomas.durand@gmail.com', 'Vos conseils SEO m\'ont déjà permis d\'améliorer le classement de mon site !', '2025-01-26 14:40:00', 1, '2025-01-26 15:20:00', ''),
(51, 11, 'Thomas Durand', 'thomas.durand@gmail.com', 'Vos conseils SEO m\'ont déjà permis d\'améliorer le classement de mon site !', '2025-01-26 14:40:00', 1, '2025-01-26 15:20:00', ''),
(52, 11, 'Julie Legrand', 'julie.legrand@hotmail.com', 'Les techniques mentionnées sont-elles applicables aux petits sites ?', '2025-01-27 10:25:00', 0, '2025-01-27 10:25:00', ''),
(53, 11, 'Julie Legrand', 'julie.legrand@hotmail.com', 'Les techniques mentionnées sont-elles applicables aux petits sites ?', '2025-01-27 10:25:00', 0, '2025-01-27 10:25:00', ''),
(54, 12, 'Nicolas Fournier', 'nicolas.fournier@gmail.com', 'La sécurité est souvent négligée, merci pour ce rappel important !', '2025-02-02 13:10:00', 1, '2025-02-02 14:00:00', ''),
(55, 12, 'Nicolas Fournier', 'nicolas.fournier@gmail.com', 'La sécurité est souvent négligée, merci pour ce rappel important !', '2025-02-02 13:10:00', 1, '2025-02-02 14:00:00', ''),
(56, 13, 'Sarah Dubois', 'sarah.dubois@yahoo.fr', 'Pourriez-vous faire un article sur les attaques CSRF spécifiquement ?', '2025-02-03 08:45:00', 1, '2025-02-03 09:30:00', 'Excellente suggestion, nous allons y travailler !'),
(57, 13, 'Sarah Dubois', 'sarah.dubois@yahoo.fr', 'Pourriez-vous faire un article sur les attaques CSRF spécifiquement ?', '2025-02-03 08:45:00', 1, '2025-02-03 09:30:00', 'Excellente suggestion, nous allons y travailler !'),
(58, 13, 'Antoine Girard', 'antoine.girard@gmail.com', 'Vue.js reste mon préféré pour sa simplicité !', '2025-02-06 15:20:00', 1, '2025-02-06 16:00:00', ''),
(59, 13, 'Antoine Girard', 'antoine.girard@gmail.com', 'Vue.js reste mon préféré pour sa simplicité !', '2025-02-06 15:20:00', 1, '2025-02-06 16:00:00', ''),
(60, 14, 'Laura Simon', 'laura.simon@hotmail.com', 'React a une communauté plus large, c\'est un avantage non négligeable.', '2025-02-07 09:35:00', 0, '2025-04-18 08:05:33', ''),
(61, 14, 'Laura Simon', 'laura.simon@hotmail.com', 'React a une communauté plus large, c\'est un avantage non négligeable.', '2025-02-07 09:35:00', 0, '2025-02-07 09:35:00', ''),
(62, 15, 'Rémi Leroy', 'remi.leroy@gmail.com', 'J\'utilise déjà plusieurs de ces outils, ils sont vraiment indispensables !', '2025-02-11 12:40:00', 1, '2025-02-11 13:15:00', ''),
(63, 15, 'Rémi Leroy', 'remi.leroy@gmail.com', 'J\'utilise déjà plusieurs de ces outils, ils sont vraiment indispensables !', '2025-02-11 12:40:00', 1, '2025-02-11 13:15:00', ''),
(64, 15, 'Claire Mercier', 'claire.mercier@yahoo.fr', 'Avez-vous des recommandations pour les outils de test de performance ?', '2025-02-12 08:25:00', 1, '2025-02-12 09:10:00', 'Nous recommandons Lighthouse et WebPageTest, nous ferons un article détaillé à ce sujet.'),
(65, 15, 'Claire Mercier', 'claire.mercier@yahoo.fr', 'Avez-vous des recommandations pour les outils de test de performance ?', '2025-02-12 08:25:00', 1, '2025-02-12 09:10:00', 'Nous recommandons Lighthouse et WebPageTest, nous ferons un article détaillé à ce sujet.'),
(66, 15, 'Hugo Blanc', 'hugo.blanc@gmail.com', 'Ce guide m\'a permis de créer ma première API avec Laravel, merci !', '2025-02-16 14:30:00', 1, '2025-02-16 15:15:00', ''),
(67, 15, 'Hugo Blanc', 'hugo.blanc@gmail.com', 'Ce guide m\'a permis de créer ma première API avec Laravel, merci !', '2025-02-16 14:30:00', 1, '2025-02-16 15:15:00', '');

-- --------------------------------------------------------

--
-- Structure de la table `competences`
--

DROP TABLE IF EXISTS `competences`;
CREATE TABLE IF NOT EXISTS `competences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text,
  `icone` varchar(255) DEFAULT NULL,
  `date_modification` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `competences`
--

INSERT INTO `competences` (`id`, `titre`, `description`, `icone`, `date_modification`) VALUES
(6, 'HTML', 'Langage de balisage pour la structure des pages web.', 'fab fa-html5', '2025-01-01 09:00:00'),
(7, 'CSS', 'Feuilles de style pour la présentation des pages web.', 'fab fa-css3-alt', '2025-01-01 09:05:00'),
(8, 'JavaScript', 'Langage de programmation pour ajouter de l\'interactivité aux sites web.', 'fab fa-js', '2025-01-01 09:10:00'),
(9, 'PHP', 'Langage de script côté serveur pour le développement web.', 'fab fa-php', '2025-01-01 09:15:00'),
(10, 'MySQL', 'Système de gestion de base de données relationnelle.', 'fas fa-database', '2025-01-01 09:20:00'),
(11, 'React', 'Bibliothèque JavaScript pour créer des interfaces utilisateur.', 'fab fa-react', '2025-01-01 09:25:00'),
(12, 'Vue.js', 'Framework JavaScript progressif pour construire des interfaces utilisateur.', 'fab fa-vuejs', '2025-01-01 09:30:00'),
(13, 'Angular', 'Framework JavaScript complet pour développer des applications web.', 'fab fa-angular', '2025-01-01 09:35:00'),
(14, 'Node.js', 'Environnement d\'exécution JavaScript côté serveur.', 'fab fa-node-js', '2025-01-01 09:40:00'),
(15, 'Laravel', 'Framework PHP élégant pour le développement web.', 'fab fa-laravel', '2025-01-01 09:45:00'),
(16, 'Git', 'Gestion de versions et collaboration avec Git et GitHub', 'fab fa-git-alt', '2025-04-18 07:53:03'),
(17, 'SEO', 'Optimisation pour les moteurs de recherche et analyse de trafic', 'fas fa-search', '2025-04-18 07:53:03'),
(18, 'UI/UX Design', 'Conception d\'interfaces utilisateur intuitives et esthétiques', 'fas fa-pencil-ruler', '2025-04-18 07:53:03'),
(19, 'Responsive Design', 'Création de sites web adaptés à tous les appareils', 'fas fa-mobile-alt', '2025-04-18 07:53:03'),
(20, 'Bootstrap', 'Développement rapide avec le framework Bootstrap', 'fab fa-bootstrap', '2025-04-18 07:53:03'),
(21, 'Docker', 'Conteneurisation d\'applications pour faciliter le déploiement', 'fab fa-docker', '2025-04-18 07:53:51'),
(22, 'MongoDB', 'Gestion de bases de données NoSQL', 'fas fa-server', '2025-04-18 07:53:51'),
(23, 'AWS', 'Déploiement et gestion d\'infrastructures cloud sur AWS', 'fab fa-aws', '2025-04-18 07:53:51'),
(24, 'GraphQL', 'Implémentation d\'APIs GraphQL pour des requêtes optimisées', 'fas fa-project-diagram', '2025-04-18 07:53:51'),
(25, 'TypeScript', 'Développement JavaScript avec typage statique', 'fab fa-js-square', '2025-04-18 07:53:51');

-- --------------------------------------------------------

--
-- Structure de la table `formations`
--

DROP TABLE IF EXISTS `formations`;
CREATE TABLE IF NOT EXISTS `formations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text,
  `duree` varchar(50) DEFAULT NULL,
  `outils` text,
  `competences_requises` text,
  `prix` varchar(50) DEFAULT NULL,
  `lien_paiement` varchar(255) DEFAULT NULL,
  `miniature` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `formations`
--

INSERT INTO `formations` (`id`, `titre`, `description`, `duree`, `outils`, `competences_requises`, `prix`, `lien_paiement`, `miniature`, `date_creation`, `date_modification`) VALUES
(16, 'SEO et Marketing Digital', '<p>Optimisez votre présence en ligne et améliorez votre visibilité</p>', '2 semaines', 'Google Analytics, SEMrush', 'Connaissances de base en marketing', '179€', 'https://payment.example.com/seo-course', 'seo.jpg', '2025-04-18 07:54:11', '2025-04-18 14:44:26'),
(14, 'PHP et MySQL pour Débutants', '<p>Bases du développement backend avec PHP et MySQL</p>', '3 semaines', 'PHP, MySQL, PhpMyAdmin', 'HTML/CSS de base', '229€', 'https://payment.example.com/php-mysql-basics', 'mdn.jpg', '2025-04-18 07:54:11', '2025-04-18 14:45:53'),
(15, 'Laravel pour Projets Professionnels', '<p>Développez des applications web complètes avec Laravel</p>', '6 semaines', 'Laravel, Eloquent ORM, Blade', 'PHP intermédiaire, bases de MySQL', '399€', 'https://payment.example.com/laravel-pro', 'img7.png', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(13, 'Développement avec React', '<p>Maîtrisez React pour créer des applications web dynamiques</p>', '5 semaines', 'React, Redux, React Router', 'JavaScript intermédiaire', '349€', 'https://payment.example.com/react-course', 'img6.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(12, 'JavaScript Avancé', '<p>Perfectionnez vos compétences en JavaScript moderne (ES6+)</p>', '2 semaines', 'Node.js, npm, Webpack', 'Connaissances de base en JavaScript', '199€', 'https://payment.example.com/js-advanced', 'javascript-propre.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(11, 'Maîtrise de WordPress', '<p>Apprenez à créer et gérer des sites WordPress professionnels</p>', '3 semaines', 'WordPress, plugins essentiels', 'Connaissances de base en HTML/CSS', '249€', 'https://payment.example.com/wordpress-course', 'optimisation-wordpress.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(10, 'Développement Web Frontend Complet', '<p>Formation complète pour maîtriser HTML, CSS et JavaScript</p>', '4 semaines', 'VS Code, Chrome DevTools', 'Aucune, accessible aux débutants', '299€', 'https://payment.example.com/frontend-course', 'web.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(9, 'Développement Web Front-End avec React ok', '<p>Savoir developper un site web complet avec le framework React</p>', '2 jours', 'JavaScript', 'Connaissance en Javascript', '100$', 'http://localhost:55050/browser/', 'javascript-propre.jpg', '2025-04-17 14:18:07', '2025-04-17 14:28:06'),
(17, 'UI/UX Design pour Développeurs', '<p>Apprenez les principes de design pour améliorer vos projets web</p>', '3 semaines', 'Figma, Adobe XD', 'Connaissances en HTML/CSS', '249€', 'https://payment.example.com/uiux-course', 'img2.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(18, 'Node.js et Express', '<p>Créez des API RESTful et des applications backend avec Node.js</p>', '4 semaines', 'Node.js, Express, MongoDB', 'JavaScript intermédiaire', '299€', 'https://payment.example.com/nodejs-course', 'img3.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(19, 'GraphQL pour APIs Modernes', '<p>Implémentez GraphQL dans vos projets pour des APIs plus flexibles</p>', '2 semaines', 'Apollo Server, GraphQL', 'Expérience en développement d\'API', '219€', 'https://payment.example.com/graphql-course', 'img9.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(20, 'Déploiement avec Docker', '<p>Maîtrisez Docker pour simplifier le déploiement de vos applications</p>', '2 semaines', 'Docker, Docker Compose', 'Connaissances en ligne de commande', '229€', 'https://payment.example.com/docker-course', 'img8.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(21, 'TypeScript pour Applications Robustes', '<p>Améliorez votre code JavaScript avec TypeScript</p>', '3 semaines', 'TypeScript, VS Code', 'JavaScript intermédiaire', '249€', 'https://payment.example.com/typescript-course', 'img5.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(22, 'AWS pour Développeurs Web', '<p>Déployez et gérez vos applications sur l\'infrastructure AWS</p>', '4 semaines', 'AWS Console, S3, EC2, Lambda', 'Connaissances de base en cloud computing', '349€', 'https://payment.example.com/aws-course', 'img1.webp', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(23, 'MongoDB pour Applications Modernes', '<p>Maîtrisez cette base de données NoSQL populaire</p>', '2 semaines', 'MongoDB, Mongoose', 'JavaScript de base', '199€', 'https://payment.example.com/mongodb-course', 'img5.webp', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(24, 'Développement d\'Applications Mobiles avec React Native', '<p>Créez des applications mobiles cross-platform</p>', '6 semaines', 'React Native, Expo', 'Connaissances en React', '399€', 'https://payment.example.com/react-native-course', 'img4.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(25, 'Progressive Web Apps (PWA)', '<p>Transformez vos sites web en applications progressives</p>', '3 semaines', 'Service Workers, Workbox', 'HTML, CSS, JavaScript avancé', '249€', 'https://payment.example.com/pwa-course', 'moi.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(26, 'Tests Automatisés pour JavaScript', '<p>Implémentez des tests unitaires et d\'intégration efficaces</p>', '2 semaines', 'Jest, Testing Library', 'JavaScript intermédiaire', '199€', 'https://payment.example.com/testing-course', 'ia-developpeurs.jpg', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(27, 'Bases de l\'Intelligence Artificielle pour Développeurs', '<p>Intégrez l\'IA dans vos projets web</p>', '4 semaines', 'TensorFlow.js, API d\'IA', 'JavaScript avancé', '349€', 'https://payment.example.com/ai-course', 'logo.png', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(28, 'Cybersécurité pour Applications Web', '<p>Protégez vos applications contre les vulnérabilités courantes</p>', '3 semaines', 'OWASP, outils d\'audit', 'Développement web intermédiaire', '299€', 'https://payment.example.com/security-course', 'logoMdn.png', '2025-04-18 07:54:11', '2025-04-18 07:54:11'),
(29, 'Tendances Web 2024', '<p>Découvrez et maîtrisez les dernières technologies web</p>', '2 semaines', 'WebAssembly, Web Components', 'HTML, CSS, JavaScript', '179€', 'https://payment.example.com/trends-course', 'tendances-web-2024.avif', '2025-04-18 07:54:11', '2025-04-18 07:54:11');

-- --------------------------------------------------------

--
-- Structure de la table `projets`
--

DROP TABLE IF EXISTS `projets`;
CREATE TABLE IF NOT EXISTS `projets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` text,
  `technologies_utilisees` varchar(255) DEFAULT NULL,
  `lien_live` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `projets`
--

INSERT INTO `projets` (`id`, `titre`, `image`, `description`, `technologies_utilisees`, `lien_live`, `date_creation`, `date_modification`) VALUES
(4, 'Site E-commerce', 'img2.jpg', 'Boutique en ligne complète avec panier, paiement et gestion des stocks.', 'WordPress, WooCommerce, PHP, MySQL, jQuery', 'https://boutique-example.com', '2025-04-18 07:54:38', '2025-04-18 14:46:22'),
(3, 'Plateforme E-learning', 'ecom.png', 'Plateforme complète de formation en ligne avec système de paiement et suivi des progrès.', 'PHP, Laravel, MySQL, React, Bootstrap', 'https://e-learning-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(5, 'Application de Gestion de Projet', 'img1.webp', 'Outil collaboratif pour la gestion de projets et le suivi des tâches.', 'React, Node.js, MongoDB, Express', 'https://gestion-projet-app.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(6, 'Portfolio Photographe', 'img2.jpg', 'Site vitrine pour un photographe professionnel avec galerie dynamique.', 'HTML5, CSS3, JavaScript, PHP', 'https://photo-portfolio-example.com', '2025-04-18 07:54:38', '2025-04-18 14:45:58'),
(8, 'Système de Réservation', 'img4.jpg', 'Application de réservation pour un restaurant avec gestion des disponibilités.', 'PHP, MySQL, JavaScript, AJAX', 'https://reservation-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(9, 'Dashboard Analytics', 'img5.jpg', 'Tableau de bord interactif pour visualiser des données commerciales.', 'React, D3.js, Node.js, MongoDB', 'https://analytics-dashboard-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(10, 'Application Météo', 'img5.webp', 'Application météo en temps réel utilisant des API externes.', 'React, API OpenWeatherMap, CSS3', 'https://meteo-app-example.com', '2025-04-18 07:54:38', '2025-04-18 12:52:40'),
(11, 'Réseau Social Professionnel', 'img7.png', 'Plateforme de mise en relation pour professionnels d\'un secteur spécifique.', 'PHP, MySQL, JavaScript, Bootstrap', 'https://reseau-pro-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(12, 'Système de Quiz en Ligne', 'img8.jpg', 'Application permettant de créer et partager des quiz interactifs.', 'React, Firebase, Bootstrap', 'https://quiz-app-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(13, 'Plateforme Immobilière', 'img9.jpg', 'Site d\'annonces immobilières avec recherche avancée et filtres.', 'Laravel, MySQL, Vue.js, Tailwind CSS', 'https://immo-platform-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(14, 'Application de Suivi Fitness', 'maint.jpg', 'Application mobile pour suivre ses performances sportives et son alimentation directe.', 'React Native, Firebase, Node.js', 'https://fitness-app-example.com', '2025-04-18 07:54:38', '2025-04-18 12:53:07'),
(15, 'Site Vitrine Association', 'mdn.jpg', 'Site web pour une association avec gestion des événements et adhésions.', 'WordPress, PHP, MySQL, JavaScript', 'https://association-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(16, 'Application de Recettes', 'moi.jpg', 'Base de données de recettes avec fonction de recherche par ingrédients.', 'React, Node.js, MongoDB, Express', 'https://recettes-app-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(17, 'Plateforme de Support Client', 'web.jpg', 'Système de tickets et base de connaissances pour l\'assistance client.', 'Laravel, MySQL, Vue.js, Bootstrap', 'https://support-platform-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(18, 'Jeu Éducatif en Ligne', 'banniere1.png', 'Jeu interactif pour l\'apprentissage des mathématiques destiné aux enfants.', 'JavaScript, Canvas API, PHP, MySQL', 'https://edu-game-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(19, 'Outil de Gestion de Contenu', 'gif.gif', 'CMS personnalisé pour un média en ligne avec workflow éditorial.', 'Laravel, MySQL, Vue.js, Tailwind CSS', 'https://cms-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(20, 'Application de Budgétisation', 'ia-developpeurs.jpg', 'Outil de suivi des dépenses et de planification financière.', 'React, Chart.js, Firebase', 'https://budget-app-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(21, 'Portfolio Développeur', 'logo - Copie.png', 'Site portfolio personnel avec présentation de projets et compétences.', 'HTML5, CSS3, JavaScript, GSAP', 'https://portfolio-dev-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38'),
(22, 'Plateforme d\'Apprentissage des Langues', 'seo.jpg', 'Application interactive pour l\'apprentissage des langues étrangères.', 'React, Node.js, MongoDB, Socket.io', 'https://langues-app-example.com', '2025-04-18 07:54:38', '2025-04-18 07:54:38');

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `prix` varchar(50) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modification` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`id`, `titre`, `description`, `image`, `prix`, `date_creation`, `date_modification`) VALUES
(7, 'Développement d\'Application Web', 'Conception et développement d\'applications web sur mesure pour répondre à vos besoins spécifiques.', 'img1.webp', 'À partir de 3500€', '2025-04-18 07:54:50', '2025-04-18 15:16:20'),
(6, 'Création de Boutique E-commerce', 'Développement complet d\'une boutique en ligne avec gestion des produits, panier, paiement sécurisé et suivi des commandes.', '6802176bb48a5.jpg', 'À partir de 2500€', '2025-04-18 07:54:50', '2025-04-18 15:16:02'),
(5, 'Développement de Site Web Vitrine', 'Création d\'un site web professionnel pour présenter votre entreprise et vos services. Inclut design personnalisé, responsive et optimisé SEO.', 'web.jpg', 'À partir de 1200€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(8, 'Refonte de Site Web', 'Modernisation de votre site existant avec nouveau design, amélioration des performances et de l\'expérience utilisateur.', 'img2.jpg', 'À partir de 1500€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(9, 'Optimisation SEO', 'Analyse et optimisation de votre site pour améliorer son classement dans les moteurs de recherche.', 'seo.jpg', 'À partir de 600€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(10, 'Maintenance Website', 'Service de maintenance régulière pour garantir la sécurité, les performances et les mises à jour de votre site.', 'maint.jpg', 'À partir de 150€/mois', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(11, 'Intégration WordPress', 'Installation et configuration de WordPress avec thème personnalisé et plugins essentiels.', 'optimisation-wordpress.jpg', 'À partir de 1000€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(12, 'Développement de Plugin WordPress', 'Création de plugins sur mesure pour étendre les fonctionnalités de votre site WordPress.', 'img3.jpg', 'À partir de 800€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(13, 'Formation Web Personnalisée', 'Sessions de formation adaptées à vos besoins pour maîtriser les technologies web ou votre CMS.', 'ia-developpeurs.jpg', 'À partir de 400€/jour', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(14, 'Audit de Performance Web', 'Analyse complète des performances de votre site et recommandations pour l\'optimisation.', 'img4.jpg', 'À partir de 500€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(15, 'Déploiement et Hébergement', 'Configuration de l\'hébergement, déploiement et mise en ligne de votre site ou application.', 'img5.jpg', 'À partir de 300€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(16, 'Développement Frontend', 'Création d\'interfaces utilisateur modernes, réactives et attrayantes avec les dernières technologies.', 'javascript-propre.jpg', 'À partir de 1800€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(17, 'Développement Backend', 'Conception et implémentation de l\'architecture serveur, APIs et bases de données.', 'img6.jpg', 'À partir de 2000€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(18, 'Création de Base de Données', 'Conception et implémentation de structures de données efficaces et sécurisées.', 'img7.png', 'À partir de 800€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(19, 'Intégration d\'API', 'Connexion de votre site à des services externes via APIs (paiement, réseaux sociaux, cartographie, etc.).', 'img8.jpg', 'À partir de 600€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(20, 'Développement d\'Application Mobile', 'Création d\'applications mobiles multiplateformes (iOS/Android) avec React Native.', 'img9.jpg', 'À partir de 4000€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(21, 'Migration de Site Web', 'Transfert sécurisé de votre site vers un nouvel hébergement ou une nouvelle technologie.', 'mdn.jpg', 'À partir de 700€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(22, 'Création de Contenu Web', 'Rédaction de contenu optimisé SEO pour votre site web (articles, descriptions, pages).', 'moi.jpg', 'À partir de 0,15€/mot', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(23, 'Setup Analytique', 'Installation et configuration d\'outils d\'analyse pour suivre les performances de votre site.', 'banniere.png', 'À partir de 400€', '2025-04-18 07:54:50', '2025-04-18 07:54:50'),
(24, 'Consultation Web', 'Sessions de conseil stratégique pour optimiser votre présence en ligne et votre stratégie digitale.', 'banniere1.png', 'À partir de 250€/heure', '2025-04-18 07:54:50', '2025-04-18 07:54:50');

-- --------------------------------------------------------

--
-- Structure de la table `temoignages`
--

DROP TABLE IF EXISTS `temoignages`;
CREATE TABLE IF NOT EXISTS `temoignages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `temoignage` text NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `profession` varchar(100) DEFAULT NULL,
  `date_modification` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `temoignages`
--

INSERT INTO `temoignages` (`id`, `nom`, `temoignage`, `date_creation`, `profession`, `date_modification`) VALUES
(2, 'Sophie Martin', 'Je recommande vivement ces services de développement web. Notre entreprise a vu une augmentation de 40% des leads depuis le lancement de notre nouveau site.', '2025-04-18 07:55:05', 'Directrice Marketing, TechSolutions', '2025-04-18 07:55:05'),
(3, 'Thomas Dupont', 'La formation WordPress que j\'ai suivie était exactement ce dont j\'avais besoin. Les explications étaient claires et j\'ai pu créer mon site en autonomie dès la fin du cours.', '2025-04-18 07:55:05', 'Entrepreneur', '2025-04-18 07:55:05'),
(4, 'Émilie Leclerc', 'Le service de maintenance mensuel nous a permis d\'oublier tous nos problèmes techniques et de nous concentrer sur notre cœur de métier. Un vrai soulagement !', '2025-04-18 07:55:05', 'Responsable Communication, Agence Créative', '2025-04-18 07:55:05'),
(5, 'Alexandre Moreau', 'Notre application web personnalisée a transformé notre processus de gestion des commandes. L\'équipe a parfaitement compris nos besoins et apporté des solutions innovantes.', '2025-04-18 07:55:05', 'Directeur des Opérations, LogiTech', '2025-04-18 07:55:05'),
(6, 'Julie Bertrand', 'L\'optimisation SEO réalisée sur notre site a donné des résultats impressionnants en seulement quelques mois. Notre trafic organique a plus que doublé !', '2025-04-18 07:55:05', 'E-commerce Manager, ModeBoutique', '2025-04-18 07:55:05'),
(7, 'Nicolas Lambert', 'La refonte de notre site e-commerce a été un succès total. L\'interface est maintenant intuitive et notre taux de conversion a augmenté significativement.', '2025-04-18 07:55:05', 'CEO, SportEquipment', '2025-04-18 07:55:05'),
(8, 'Marion Rousseau', 'La formation sur mesure m\'a permis d\'acquérir rapidement les compétences dont j\'avais besoin pour gérer notre blog d\'entreprise. Excellente pédagogie !', '2025-04-18 07:55:05', 'Chargée de Communication, EcoResponsable', '2025-04-18 07:55:05'),
(9, 'Paul Dubois', 'Le développement de notre application mobile a été livré dans les délais et le budget convenus. La qualité du code et le design sont impeccables.', '2025-04-18 07:55:05', 'CTO, StartupHealth', '2025-04-18 07:55:05'),
(10, 'Aurélie Simon', 'Notre nouveau site vitrine nous a permis de moderniser notre image et de mieux présenter nos services. Nos clients sont unanimes sur la qualité du résultat.', '2025-04-18 07:55:05', 'Directrice, Cabinet Juridique', '2025-04-18 07:55:05'),
(11, 'Mathieu Girard', 'L\'audit de performance a identifié des problèmes que nous n\'aurions jamais trouvés nous-mêmes. Les améliorations apportées ont rendu notre site beaucoup plus rapide.', '2025-04-18 07:55:05', 'Responsable IT, AgenceVoyage', '2025-04-18 07:55:05'),
(12, 'Camille Lefevre', 'Le plugin WordPress développé sur mesure a considérablement simplifié notre processus de réservation en ligne. Un investissement qui a rapidement porté ses fruits.', '2025-04-18 07:55:05', 'Gérante, SpaConcept', '2025-04-18 07:55:05'),
(13, 'Antoine Mercier', 'La migration de notre site s\'est déroulée sans accroc et sans aucune interruption de service. Un travail de professionnel !', '2025-04-18 07:55:05', 'Administrateur Système, MediaGroup', '2025-04-18 07:55:05'),
(14, 'Céline Petit', 'Le contenu rédigé pour notre blog est parfaitement optimisé SEO et correspond exactement à notre ton de marque. Nos lecteurs l\'apprécient beaucoup.', '2025-04-18 07:55:05', 'Content Manager, BlogMode', '2025-04-18 07:55:05'),
(15, 'Romain Bernard', 'Notre boutique en ligne fonctionne parfaitement depuis son lancement et les ventes dépassent nos attentes. Le système de paiement est simple et sécurisé.', '2025-04-18 07:55:05', 'Fondateur, ArtisanatLocal', '2025-04-18 07:55:05'),
(16, 'Isabelle Laurent', 'La formation React m\'a permis de monter rapidement en compétence et d\'appliquer immédiatement les concepts appris à nos projets internes.', '2025-04-18 07:55:05', 'Développeuse Frontend, WebAgency', '2025-04-18 07:55:05'),
(17, 'François Morel', 'Le dashboard personnalisé développé pour notre entreprise nous permet maintenant de suivre nos KPIs en temps réel et de prendre des décisions éclairées.', '2025-04-18 07:55:05', 'Directeur Commercial, DataInsight', '2025-04-18 07:55:05'),
(18, 'Nathalie Leroy', 'La consultation stratégique a transformé notre approche du digital. Les conseils reçus nous ont permis d\'élaborer une feuille de route claire pour notre développement en ligne.', '2025-04-18 07:55:05', 'CEO, ConseilMarketing', '2025-04-18 07:55:05'),
(19, 'Sébastien Garcia', 'L\'intégration des différentes APIs dans notre système a considérablement amélioré l\'expérience utilisateur et automatisé de nombreux processus manuels.', '2025-04-18 07:55:05', 'Product Manager, AutomateTech', '2025-04-18 07:55:05'),
(20, 'Laure Fournier', 'Le site WordPress créé pour notre association est parfaitement adapté à nos besoins et très facile à mettre à jour, même pour des non-techniciens comme nous.', '2025-04-18 07:55:05', 'Présidente, AssociationSolidarité', '2025-04-18 07:55:05'),
(21, 'Vincent Lemoine', 'L\'application de gestion développée sur mesure a révolutionné notre organisation interne. Un grand merci pour ce travail de qualité !', '2025-04-18 07:55:05', 'Gérant, PME Construction', '2025-04-18 07:55:05');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
